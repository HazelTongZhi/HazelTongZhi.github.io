PARTS MANIFEST
==========================================
2 x Frame.stl
2 x Wheel.stl
9 x Bracket1.stl

8 x Braket2.stl
8 x Basket.stl

SUGGESTED ASSEMBLY
==========================================
The 8 wheel supporting brackets should be trimmed and excesses smoothed with a
hot hobby knife or soldering iron. You may flatten the ends of the basket
supporting brackets but in my experience, I found they tend to jam up and not 
hang freely if done incorrectly.

A washer between the wheel and the frame assembly is also recommended.

